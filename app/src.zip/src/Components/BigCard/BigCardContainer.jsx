import React from 'react';
import BigCard from './BigCard';

const BigCardContainer = props => {
    return (
        <BigCard/>
    )
}

export default BigCardContainer