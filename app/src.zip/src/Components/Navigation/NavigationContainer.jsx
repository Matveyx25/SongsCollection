import React from 'react';
import Navigation from './Navigation';

const NavigationContainer = props => {
    return (
        <Navigation/>
    )
}

export default NavigationContainer