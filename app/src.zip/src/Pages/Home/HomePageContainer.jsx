import React from 'react';
import HomePage from './HomePage';

const HomePageContainer = props => {
    return (
        <HomePage/>
    )
}

export default HomePageContainer