import React from 'react';
import SongPageContainer from '../SongPage/SongPageContainer';
import s from './BookPage.module.scss'


const BookPage = props => {
    return (
        <>
            <SongPageContainer/>
        </>
    )
}

export default BookPage