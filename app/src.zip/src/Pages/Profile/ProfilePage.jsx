import React from 'react';
import s from './ProfilePage.module.scss'


const ProfilePage = props => {
    return (
        <h1>
            Profile
        </h1>
    )
}

export default ProfilePage