import React from 'react';
import ProfilePage from './ProfilePage';

const ProfilePageContainer = props => {
    return (
        <ProfilePage/>
    )
}

export default ProfilePageContainer