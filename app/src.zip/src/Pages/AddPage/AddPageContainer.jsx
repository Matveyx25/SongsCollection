import React from 'react';
import AddPage from './AddPage';

const AddPageContainer = props => {
    return (
        <AddPage/>
    )
}

export default AddPageContainer