import React from 'react';
import s from './AddPage.module.scss'


const AddPage = props => {
    return (
        <h1>
            Add
        </h1>
    )
}

export default AddPage